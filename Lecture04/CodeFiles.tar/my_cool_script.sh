#This is my better script
# Done using different approaches
#This script is not very good
#This script is not good
